import 'package:flutter/material.dart';

class FiltersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fem = screenWidth / 428; // Faktor pengukuran yang digunakan

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Bagian status bar
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 26 * fem),
              padding: EdgeInsets.fromLTRB(21 * fem, 8 * fem, 14 * fem, 2 * fem),
              width: double.infinity,
              decoration: BoxDecoration(
                color: Color(0xffe2e2e2),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0 * fem, 4 * fem, 290 * fem, 0 * fem),
                    width: 54 * fem,
                    height: 21 * fem,
                    child: Image.network(
                      '[Image url]',
                      width: 54 * fem,
                      height: 21 * fem,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 4 * fem),
                    padding: EdgeInsets.fromLTRB(0 * fem, 9 * fem, 0 * fem, 0 * fem),
                    width: 67 * fem,
                    height: 21 * fem,
                    child: Container(
                      width: double.infinity,
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 6.5 * fem, 0 * fem),
                            width: 16.5 * fem,
                            height: 10 * fem,
                            child: Image.network(
                              '[Image url]',
                              width: 16.5 * fem,
                              height: 10 * fem,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 4.75 * fem, 0 * fem),
                            width: 14.25 * fem,
                            height: 10 * fem,
                            child: Image.network(
                              '[Image url]',
                              width: 14.25 * fem,
                              height: 10 * fem,
                            ),
                          ),
                          Container(
                            width: 25 * fem,
                            height: 12 * fem,
                            child: Image.network(
                              '[Image url]',
                              width: 25 * fem,
                              height: 12 * fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Bagian judul "filters"
            Container(
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 42 * fem, 0 * fem),
              child: Text(
                'filters',
                style: TextStyle(
                  fontSize: 32 * fem,
                  fontWeight: FontWeight.w600,
                  color: Color(0xff000000),
                ),
              ),
            ),
            // Bagian konten filter
            // Tambahkan konten filter sesuai kebutuhan di sini
          ],
        ),
      ),
    );
  }
}

